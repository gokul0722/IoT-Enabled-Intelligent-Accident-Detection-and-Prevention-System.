const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

let accidentLogs = [];

app.get("/", (req, res) => {
  res.send("IoT Accident Detection Backend Running");
});

app.post("/api/accident", (req, res) => {
  const data = {
    id: accidentLogs.length + 1,
    vehicleId: req.body.vehicleId || "Unknown",
    vibration: req.body.vibration || 0,
    gas: req.body.gas || 0,
    status: req.body.status || "NORMAL",
    location: req.body.location || "Unknown",
    time: new Date().toLocaleString()
  };

  accidentLogs.unshift(data);
  console.log("Alert Received:", data);

  res.status(201).json({ message: "Alert saved", data });
});

app.get("/api/accidents", (req, res) => {
  res.json(accidentLogs);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
