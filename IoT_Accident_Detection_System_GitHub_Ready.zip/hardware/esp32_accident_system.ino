#include <WiFi.h>
#include <HTTPClient.h>

const char* ssid = "YOUR_WIFI_NAME";
const char* password = "YOUR_WIFI_PASSWORD";
String serverURL = "http://YOUR_SERVER_IP:5000/api/accident";

#define VIBRATION_PIN 34
#define MQ_SENSOR_PIN 35
#define BUZZER_PIN 25
#define RED_LED 26
#define GREEN_LED 27

int vibrationThreshold = 1500;
int gasThreshold = 1800;

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);

  digitalWrite(GREEN_LED, HIGH);
  digitalWrite(RED_LED, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\\nWiFi Connected");
  Serial.println(WiFi.localIP());
}

void sendAlert(int vibrationValue, int gasValue, String status) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverURL);
    http.addHeader("Content-Type", "application/json");

    String payload = "{";
    payload += "\\"vehicleId\\":\\"TN-ESP32-001\\",";
    payload += "\\"vibration\\":" + String(vibrationValue) + ",";
    payload += "\\"gas\\":" + String(gasValue) + ",";
    payload += "\\"status\\":\\"" + status + "\\",";
    payload += "\\"location\\":\\"Salem, Tamil Nadu\\"";
    payload += "}";

    int code = http.POST(payload);
    Serial.println(code);
    http.end();
  }
}

void loop() {
  int vibrationValue = analogRead(VIBRATION_PIN);
  int gasValue = analogRead(MQ_SENSOR_PIN);

  Serial.print("Vibration: ");
  Serial.print(vibrationValue);
  Serial.print(" | Gas: ");
  Serial.println(gasValue);

  if (vibrationValue > vibrationThreshold) {
    digitalWrite(RED_LED, HIGH);
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(BUZZER_PIN, HIGH);
    sendAlert(vibrationValue, gasValue, "ACCIDENT_DETECTED");
    delay(5000);
    digitalWrite(BUZZER_PIN, LOW);
  } else if (gasValue > gasThreshold) {
    digitalWrite(RED_LED, HIGH);
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(BUZZER_PIN, HIGH);
    sendAlert(vibrationValue, gasValue, "ALCOHOL_OR_SMOKE_ALERT");
    delay(3000);
    digitalWrite(BUZZER_PIN, LOW);
  } else {
    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(BUZZER_PIN, LOW);
  }

  delay(1000);
}
