const API_URL = "http://localhost:5000/api/accidents";

async function loadData() {
  try {
    const response = await fetch(API_URL);
    const logs = await response.json();

    document.getElementById("totalAlerts").innerText = logs.length;
    document.getElementById("accidentCount").innerText =
      logs.filter(x => x.status === "ACCIDENT_DETECTED").length;
    document.getElementById("gasCount").innerText =
      logs.filter(x => x.status === "ALCOHOL_OR_SMOKE_ALERT").length;

    const table = document.getElementById("logTable");
    table.innerHTML = "";

    if (logs.length === 0) {
      table.innerHTML = `<tr><td colspan="7">No data found</td></tr>`;
      return;
    }

    logs.forEach(log => {
      table.innerHTML += `
        <tr>
          <td>${log.id}</td>
          <td>${log.vehicleId}</td>
          <td>${log.status}</td>
          <td>${log.vibration}</td>
          <td>${log.gas}</td>
          <td>${log.location}</td>
          <td>${log.time}</td>
        </tr>
      `;
    });
  } catch (error) {
    console.log(error);
  }
}

loadData();
setInterval(loadData, 5000);
